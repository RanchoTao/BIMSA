# 步骤1：导入库
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

# 步骤2：构造交易数据集
transactions = [
    {"牛奶", "面包", "尿布"},
    {"面包", "尿布", "啤酒"},
    {"牛奶", "尿布", "啤酒", "鸡蛋"},
    {"面包", "牛奶", "尿布", "可乐"},
    {"面包", "牛奶", "尿布"},
    {"啤酒", "尿布"},
    {"牛奶", "尿布", "鸡蛋"},
    {"面包", "尿布", "啤酒"},
    {"牛奶", "面包"},
    {"尿布", "啤酒"}
]

# 步骤3：独热编码交易数据
te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

# 步骤4：挖掘频繁项集
frequent_itemsets = apriori(df, min_support=0.3, use_colnames=True)

# 步骤5：生成关联规则
rules = association_rules(frequent_itemsets, metric="confidence", min_threshold=0.6)

# 步骤6：打印规则表与解释
print("=== 频繁项集 ===")
print(frequent_itemsets)
print("\n=== 关联规则表 ===")
print(rules[["antecedents", "consequents", "support", "confidence", "lift"]])

# 示例规则解释（需根据实际输出调整）
print("\n=== 规则解释（示例）===")
print("- 规则 {面包} → {尿布}：购买面包时100%会买尿布，两者强关联。")
print("- 规则 {牛奶} → {尿布}：购买牛奶时有83%概率买尿布，存在正向关联。")