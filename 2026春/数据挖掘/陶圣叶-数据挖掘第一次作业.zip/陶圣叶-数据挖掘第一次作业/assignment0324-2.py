import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
# 若需从sklearn加载Wine数据集（示例）：
from sklearn.datasets import load_wine
wine = load_wine()
df_wine = pd.DataFrame(wine.data, columns=wine.feature_names)
df_wine['target_name'] = wine.target_names[wine.target]  # 新增类别名称列
cols = ['alcohol', 'malic_acid', 'color_intensity', 'hue', 'proline']
stat_result = df_wine[cols].describe()
print(stat_result)
#特征相关性：alcohol与hue的散点图中，整体呈弱负相关趋势（即酒精含量越高，hue值略低）；

#类别差异：proline特征上，不同target_name（如class_0/class_1/class_2）的数值区间差异显著，class_0的proline普遍更高；

#分布集中性：color_intensity的标准差（describe()输出）较小，说明该特征数值分布更集中。

import numpy as np

def standardize(x):
    """
    输入：一维 numpy 数组 x
    输出：标准化后的数组 (x - 均值) / 标准差
    """
    mean_val = np.mean(x)    # 计算均值
    std_val = np.std(x)      # 计算标准差（默认总体标准差，ddof=0）
    return (x - mean_val) / std_val
alcohol_arr = df_wine['alcohol'].to_numpy()  # 转为一维numpy数组
alcohol_standardized = standardize(alcohol_arr)
print("标准化后均值：", np.mean(alcohol_standardized))  # 理论上接近0
print("标准化后标准差：", np.std(alcohol_standardized))  # 理论上接近1

'''
问题1：直接输入原始特征到分类模型可能带来的问题
求解目的：分析特征尺度差异对模型训练与预测的影响。  
当不同特征量纲（数值范围）差异极大时，直接输入模型会引发两类核心问题：  
1. 特征权重失衡：对基于距离计算（如K近邻KNN）、梯度更新（如逻辑回归梯度下降、神经网络反向传播）的模型，大数值特征会“主导”目标函数。例如Wine数据集中proline数值远大于alcohol，若用KNN计算样本距离，proline的微小变化对距离的影响会远超过alcohol的大幅变化，导致模型几乎只关注大尺度特征，忽略小尺度特征的有效信息。  
2. 优化效率低下：以梯度下降类模型（如线性判别分析LDA、神经网络）为例，不同特征的梯度量级因尺度差异悬殊，会使参数更新方向“混乱”，导致模型收敛速度极慢，甚至无法收敛到最优解。  
问题2：为什么很多模型需要对特征进行“标准化/归一化”？
求解目的：解释特征尺度统一的必要性。  
标准化（如Z - score： x'=\frac{x-\mu}{\sigma} ，使特征均值为0、方差为1）或归一化（如Min - Max： x'=\frac{x-\min}{\max-\min} ，使特征缩放到[0,1]区间），本质是消除特征间的量纲差异，让所有特征对模型的“贡献权重”处于同一量级，从而解决上述问题：  
对基于距离的模型（KNN、SVM、决策树衍生算法等）：标准化后特征距离的计算更公平，小尺度特征的“话语权”不会被大尺度特征碾压。  
对基于梯度优化的模型（逻辑回归、多层感知机、线性回归等）：各特征梯度更新的步长量级更接近，模型能更快、更稳定地收敛到最优解。  
对树模型外的多数统计学习模型：统一尺度后，模型参数（如线性模型系数）的可解释性更强——系数大小能直接反映对应特征对目标变量的影响强度。  
问题3：对特征尺度“非常敏感”的模型例子
求解目的：结合特征尺度敏感的核心逻辑，选取典型模型。  
K近邻（KNN） 是最具代表性的“尺度敏感型”模型。其核心是通过样本间距离（如欧氏距离） 衡量相似度，进而找到最近的 k 个邻居做预测。若特征尺度差异大，大数值特征的“距离占比”会严重挤压小数值特征的权重。例如Wine数据中，proline数值（假设范围100 - 1500）远大于alcohol（假设范围8 - 15），计算两个样本距离时，proline的1个单位变化对距离的影响，可能是alcohol的10倍以上，导致模型完全偏离“公平比较特征相似性”的初衷，预测结果也会严重失真。  
（拓展补充：逻辑回归（梯度下降优化版）、支持向量机（RBF核）、神经网络等也因依赖距离/梯度计算，对尺度较敏感；但KNN是“纯依赖距离”的模型，敏感程度更具典型性。）
'''