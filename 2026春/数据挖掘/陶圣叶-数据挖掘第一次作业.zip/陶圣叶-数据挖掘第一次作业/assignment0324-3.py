# ====================== 第一部分：Iris数据集分析 ======================
from sklearn.datasets import load_iris
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. 加载Iris数据集
print("正在加载Iris数据集...")
iris = load_iris()
print(f"数据集加载完成，包含 {iris.data.shape[1]} 个特征，{iris.data.shape[0]} 个样本")

# 2. 创建DataFrame
df_iris = pd.DataFrame(iris.data, columns=iris.feature_names)
df_iris['target'] = iris.target
df_iris['target_name'] = df_iris['target'].map(lambda x: iris.target_names[x])

# 3. 显示基本信息
print("\n=== Iris数据集基本信息 ===")
print(df_iris.info())

print("\n=== 前5行数据 ===")
print(df_iris.head())

print("\n=== 按类别的特征均值 ===")
mean_by_class = df_iris.groupby('target_name').mean()
print(mean_by_class)

# 4. 绘制箱线图
print("\n正在绘制箱线图...")
plt.figure(figsize=(12, 6))
melt_df = df_iris.melt(
    id_vars="target_name", 
    var_name="feature", 
    value_name="value"
)
sns.boxplot(data=melt_df, x="target_name", y="value", hue="feature", palette="Set2")
plt.title("Iris数据集各特征箱线图（按类别分组）", fontsize=14, fontweight='bold')
plt.xlabel("鸢尾花类别", fontsize=12)
plt.ylabel("特征值", fontsize=12)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', title='特征')
plt.tight_layout()
plt.show()

# ====================== 第二部分：超市销售数据集分析 ======================
import warnings
warnings.filterwarnings('ignore')

# 1. 尝试加载超市销售数据集
print("\n" + "="*60)
print("开始分析超市销售数据集...")

try:
    # 注意：此处文件路径需要根据实际情况调整
    df_sales = pd.read_csv("supermarket_sales.csv")
    print("数据集加载成功！")
    
    # 2. 显示基本信息
    print("\n=== 数据集基本信息 ===")
    print(f"数据集形状: {df_sales.shape}")
    print(f"列名: {list(df_sales.columns)}")
    
    print("\n=== 前5行数据 ===")
    print(df_sales.head())
    
    print("\n=== 数据信息（类型、非空数）===")
    print(df_sales.info())
    
    print("\n=== 数值特征统计量 ===")
    print(df_sales.describe())
    
    # 3. 数据可视化
    print("\n正在生成可视化图表...")
    
    # 创建子图
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # 子图1：直方图
    if 'gross income' in df_sales.columns:
        axes[0].hist(df_sales['gross income'], bins=20, color='skyblue', edgecolor='black', alpha=0.7)
        axes[0].set_title('销售额分布直方图', fontsize=12, fontweight='bold')
        axes[0].set_xlabel('销售额', fontsize=10)
        axes[0].set_ylabel('频数', fontsize=10)
        axes[0].grid(True, alpha=0.3)
    else:
        axes[0].text(0.5, 0.5, "'gross income'列不存在", 
                    ha='center', va='center', transform=axes[0].transAxes)
        axes[0].set_title('列名不匹配', fontsize=12)
    
    # 子图2：箱线图
    if 'Gender' in df_sales.columns and 'Rating' in df_sales.columns:
        sns.boxplot(data=df_sales, x='Gender', y='Rating', ax=axes[1], palette='pastel')
        axes[1].set_title('评分分布（按性别分组）', fontsize=12, fontweight='bold')
        axes[1].set_xlabel('性别', fontsize=10)
        axes[1].set_ylabel('评分', fontsize=10)
    else:
        axes[1].text(0.5, 0.5, "需要的列不存在", 
                    ha='center', va='center', transform=axes[1].transAxes)
        axes[1].set_title('列名不匹配', fontsize=12)
    
    plt.suptitle('超市销售数据集分析', fontsize=16, fontweight='bold')
    plt.tight_layout()
    plt.show()
    
    # 4. 迷你EDA报告
    print("\n" + "="*60)
    print("超市销售数据集迷你 EDA 报告")
    print("="*60)
    print("""
    数据集概况：
    该数据集记录某超市3个月内不同分支、商品类别、顾客性别的销售交易，
    包含销售额、时间、评分等字段。
    
    关键发现：
    1. 数据集包含 {rows} 行，{cols} 列
    2. 数值特征：{num_cols} 个，分类特征：{cat_cols} 个
    3. 缺失值情况：{missing}
    
    有意思的特征：
    - 销售额/毛利：反映盈利效率
    - 评分：顾客满意度指标
    - 商品类别：多分类维度
    - 时间戳：可用于时序分析
    
    适用任务：
    1. 分类任务：预测商品类别或顾客性别
    2. 回归任务：预测销售额或评分
    3. 时序分析：分析销售趋势和季节性
    4. 关联分析：发现商品购买模式
    """.format(
        rows=df_sales.shape[0],
        cols=df_sales.shape[1],
        num_cols=len(df_sales.select_dtypes(include=['int64', 'float64']).columns),
        cat_cols=len(df_sales.select_dtypes(include=['object']).columns),
        missing="无缺失值" if df_sales.isnull().sum().sum() == 0 else f"{df_sales.isnull().sum().sum()}个缺失值"
    ))
    
except FileNotFoundError:
    print("错误：未找到'supermarket_sales.csv'文件")
    print("请确保文件在当前目录下，或使用正确的文件路径")
    print("示例：df_sales = pd.read_csv('你的文件路径/supermarket_sales.csv')")
    
except Exception as e:
    print(f"发生错误：{type(e).__name__}: {e}")

print("\n" + "="*60)
print("数据分析完成！")
print("="*60)

'''
超市销售数据集迷你 EDA 报告  
该数据集记录某超市3个月内不同分支、商品类别、顾客性别的销售交易，含销售额、时间、评分等字段。  

- 有意思的特征：`gross income`（单笔毛利，反映盈利效率）、`Rating`（顾客满意度，离散评分）、`Product line`（商品类别，多分类维度）。  
- 适用任务：因含分类目标（如`Product line`）和数值目标（如`gross income`），适合**分类（预测商品类别）**或**回归（预测销售额）**；也可结合时间分析销售趋势（时序任务）。
'''