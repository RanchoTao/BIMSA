import pandas as pd

# 加载评分数据：包含user_id、movie_id、rating、timestamp
ratings = pd.read_csv('ml-100k/u.data', sep='\t', names=['user_id', 'movie_id', 'rating', 'timestamp'])
# 加载电影信息：包含movie_id、title等
movies = pd.read_csv('ml-100k/u.item', sep='|', encoding='latin-1', names=['movie_id', 'title', 'release_date', 'video_release', 'IMDb_URL', 
                                                                           'unknown', 'Action', 'Adventure', 'Animation', 'Children', 'Comedy',
                                                                           'Crime', 'Documentary', 'Drama', 'Fantasy', 'Film-Noir', 'Horror',
                                                                           'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western'])
# 保留所需列
ratings = ratings[['user_id', 'movie_id', 'rating']]
movies = movies[['movie_id', 'title']]
# 获取前200个最常见的用户和电影
top_users = ratings['user_id'].value_counts().index[:200]
top_movies = ratings['movie_id'].value_counts().index[:200]
ratings_subset = ratings[(ratings['user_id'].isin(top_users)) & (ratings['movie_id'].isin(top_movies))]

# 创建评分矩阵，行为用户，列为电影，值为评分，缺失值填0
rating_matrix = ratings_subset.pivot_table(index='user_id', columns='movie_id', values='rating', fill_value=0)
# 转置评分矩阵，使行为电影，列为用户
item_matrix = rating_matrix.T
# 计算相关性矩阵
item_similarity = item_matrix.corr(method='pearson')  # 或使用余弦相似度：from sklearn.metrics.pairwise import cosine_similarity
# 注意：对角线元素（自相关）可设为0以避免自我推荐
import numpy as np
np.fill_diagonal(item_similarity.values, 0)
def predict_ratings(user_vector, item_similarity):
    """预测用户对所有电影的评分：基于物品相似性加权平均"""
    # user_vector: 用户对电影的评分向量（1D数组，长度等于电影数）
    # 计算预测评分 = (相似性矩阵 * 用户评分向量) / 相似性绝对值之和
    pred = np.dot(item_similarity, user_vector) / np.abs(item_similarity).sum(axis=1)
    return pred

# 选择用户u，这里随机选user_id=1（假设在子集中）
user_id = 1
if user_id in rating_matrix.index:
    user_ratings = rating_matrix.loc[user_id].values  # 用户的实际评分向量
    predicted_ratings = predict_ratings(user_ratings, item_similarity)
    
    # 获取用户未评分的电影索引（实际评分为0的位置）
    unrated_indices = np.where(user_ratings == 0)[0]
    # 基于预测评分排序，取Top-5
    top_5_indices = predicted_ratings[unrated_indices].argsort()[-5:][::-1]
    top_5_movie_ids = rating_matrix.columns[top_5_indices]
    
    # 映射电影ID到标题
    top_5_movies = movies[movies['movie_id'].isin(top_5_movie_ids)]['title']
else:
    top_5_movies = "用户ID不在子集中，请检查数据。"
print("Top-5推荐电影：", top_5_movies.tolist())