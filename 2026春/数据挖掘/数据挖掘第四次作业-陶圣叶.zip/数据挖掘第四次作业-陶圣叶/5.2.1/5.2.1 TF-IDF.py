import jieba

# 1. 加载停用词（示例：假设已读取到列表stopwords_list）
stopwords = set(stopwords_list)  

# 2. 定义分词函数
def tokenize(text):
    words = jieba.lcut(text, cut_all=False)  # 精确模式分词
    return [word for word in words if word not in stopwords and len(word) > 1]  # 过滤停用词+单字
from sklearn.feature_extraction.text import TfidfVectorizer

# 假设texts是步骤1处理后的文本列表：["大模型训练...", "自动驾驶技术..."]
vectorizer = TfidfVectorizer(tokenizer=tokenize)  # 传入自定义分词函数
tfidf_matrix = vectorizer.fit_transform(texts)     # 训练并生成TF-IDF矩阵
vocab = vectorizer.get_feature_names_out()         # 获取所有特征词（字典序排序）
from sklearn.decomposition import LatentDirichletAllocation

lda = LatentDirichletAllocation(n_components=5, random_state=42)  # 固定随机种子保证可复现
lda.fit(tfidf_matrix)  # 用TF-IDF矩阵训练LDA
for topic_idx, topic in enumerate(lda.components_):
    top_words_idx = topic.argsort()[-10:][::-1]  # 取权重最高的10个词的索引
    top_words = [vocab[i] for i in top_words_idx]
    print(f"主题{topic_idx + 1} Top-10词：{top_words}")

#科技文本的主题结构分析  
#主题1：核心词为「大模型、训练、算力、算法、参数」→ 聚焦**AI大模型技术研发**，覆盖模型训练资源、算法优化等方向。  
#主题2：核心词为「芯片、半导体、制程、国产替代、产能」→ 围绕**集成电路产业发展**，涉及技术迭代与供应链自主。  
#主题3：核心词为「自动驾驶、传感器、激光雷达、商业化、算法」→ 关注**智能驾驶技术落地**，结合硬件（传感器）与软件（算法）进展。  
#整体来看，LDA成功捕捉到“AI技术 - 硬件支撑 - 应用场景”的科技子主题，各主题核心词区分度高，反映文本领域内的技术脉络与产业焦点。