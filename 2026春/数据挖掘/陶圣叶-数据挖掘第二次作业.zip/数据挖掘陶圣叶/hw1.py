import itertools
import time
import pandas as pd
import numpy as np
from typing import List, Dict, Tuple

class BUCCalculator:
    """
    BUC (Bottom-Up Construction) 算法实现，用于计算 Iceberg Cube。
    """
    def __init__(self, data: pd.DataFrame, k: int):
        """
        初始化计算器。
        :param data: pandas DataFrame，每一列是一个维度。
        :param k: iceberg条件阈值，count >= k
        """
        self.data = data.reset_index(drop=True)
        self.k = k
        self.dimensions = list(data.columns)
        self.results = {}  # 存储最终结果，格式：{'A,B': 15, 'A': 30}
        self.stats = {}    # 统计每个cuboid的非空单元数，格式同self.results

    def _buc(self, partition: pd.DataFrame, current_dims: List[str], depth: int):
        """
        BUC算法的递归核心。
        :param partition: 当前分区数据
        :param current_dims: 当前已固定的维度列表
        :param depth: 当前递归深度，对应开始处理的维度索引
        """
        # 1. 计算当前分区的总计数（度量）
        total_count = len(partition)
        if total_count == 0:
            return

        # 2. 生成当前cuboid的键 (已排序，以便统一格式如 'A,C')
        cuboid_key = ','.join(sorted(current_dims)) if current_dims else 'ALL'

        # 3. 如果满足iceberg条件，则保存结果
        if total_count >= self.k:
            # 保存聚合结果（这里只存计数，也可扩展存具体数据）
            self.results[cuboid_key] = total_count
            # 更新该cuboid的非空单元数统计（当前分区即一个单元，计数>0）
            self.stats[cuboid_key] = self.stats.get(cuboid_key, 0) + 1

            # 4. 递归处理更高维度的cuboid
            for i in range(depth, len(self.dimensions)):
                dim = self.dimensions[i]
                # 按当前维度分组
                grouped = partition.groupby(dim, as_index=False)
                for _, sub_partition in grouped:
                    # 固定新维度，递归
                    new_dims = current_dims + [dim]
                    self._buc(sub_partition, new_dims, i + 1)

    def compute(self) -> Tuple[Dict, Dict]:
        """
        启动BUC计算。
        :return: (results, stats) 结果字典和统计字典
        """
        self.results.clear()
        self.stats.clear()
        # 从最顶层（'ALL' cuboid）开始递归
        self._buc(self.data, [], 0)
        return self.results, self.stats

    def print_summary(self):
        """按格式打印非空单元数统计摘要。"""
        print("Cuboid 非空单元数统计摘要:")
        # 按维度数排序输出
        for key in sorted(self.stats.keys(), key=lambda x: (len(x.split(',')), x)):
            # 将逗号分隔的键转换为题目要求的格式，如 A,B,C -> ABC
            display_key = key.replace(',', '') if key != 'ALL' else 'ALL'
            print(f"◯ {display_key}: {self.stats[key]}")
        print(f"\n总计满足条件的Cuboid数量: {len(self.stats)}")


# ====================== 实验与测试部分 ======================
def generate_test_data(num_records: int, dims_config: Dict[str, int], seed=42):
    """
    生成随机测试数据集。
    :param num_records: 记录数
    :param dims_config: 维度配置，如 {'A': 5, 'B': 3, 'C': 4} 表示A有5个可能值
    :param seed: 随机种子
    :return: pandas DataFrame
    """
    np.random.seed(seed)
    data = {}
    for dim, card in dims_config.items():
        # 为每个维度生成随机值
        data[dim] = np.random.choice([f"{dim}{i+1}" for i in range(card)], num_records)
    return pd.DataFrame(data)

def run_experiment(data, k, exp_name):
    """
    运行单次实验并记录结果。
    """
    print(f"\n{'='*50}")
    print(f"实验: {exp_name}")
    print(f"参数: 数据量={len(data)}, 维度={list(data.columns)}, k={k}")
    
    start_time = time.time()
    calculator = BUCCalculator(data, k)
    results, stats = calculator.compute()
    end_time = time.time()
    
    calculator.print_summary()
    print(f"运行时间: {end_time - start_time:.4f} 秒")
    
    return {
        'exp_name': exp_name,
        'num_records': len(data),
        'num_dims': len(data.columns),
        'k': k,
        'time': end_time - start_time,
        'cuboid_count': len(stats)
    }

if __name__ == "__main__":
    # 示例：使用一个小型数据集演示
    print("BUC Iceberg Cube 计算演示")
    print("="*50)
    
    # 1. 创建一个简单示例数据 (3维)
    sample_data = pd.DataFrame({
        'A': ['A1', 'A1', 'A2', 'A2', 'A3'],
        'B': ['B1', 'B2', 'B1', 'B2', 'B1'],
        'C': ['C1', 'C1', 'C2', 'C2', 'C1']
    })
    print("示例数据:")
    print(sample_data)
    
    # 2. 计算 iceberg cube (k=2)
    calc = BUCCalculator(sample_data, k=2)
    results, stats = calc.compute()
    calc.print_summary()
    
    # 3. 开始系统性实验（可根据需要调整参数）
    all_results = []
    
    # 实验1：测试维度数变化 (固定记录数=5000, k=10)
    print("\n\n实验系列1: 维度数变化的影响")
    base_dims = {'A': 5, 'B': 4, 'C': 6, 'D': 3, 'E': 5, 'F': 4}
    for d in [3, 4, 5, 6]:
        dims_subset = dict(list(base_dims.items())[:d])
        data = generate_test_data(num_records=5000, dims_config=dims_subset)
        res = run_experiment(data, k=10, exp_name=f"维度数={d}")
        all_results.append(res)
    
    # 实验2：测试记录数变化 (固定维度=5, k=10)
    print("\n\n实验系列2: 记录数变化的影响")
    dims_config = dict(list(base_dims.items())[:5])
    for n in [1000, 5000, 10000]:
        data = generate_test_data(num_records=n, dims_config=dims_config)
        res = run_experiment(data, k=10, exp_name=f"记录数={n}")
        all_results.append(res)
    
    # 实验3：测试阈值k变化 (固定维度=5, 记录数=5000)
    print("\n\n实验系列3: 阈值k变化的影响")
    data = generate_test_data(num_records=5000, dims_config=dims_config)
    for k_val in [5, 10, 20, 50]:
        res = run_experiment(data, k=k_val, exp_name=f"k={k_val}")
        all_results.append(res)
    
    # 汇总实验结果表格
    print("\n\n" + "="*60)
    print("实验汇总表格:")
    print("="*60)
    summary_df = pd.DataFrame(all_results)
    print(summary_df.to_string(index=False))
    
    # 简单分析
    print("\n简要趋势分析:")
    print("1. 维度增加 -> 运行时间和输出cuboid数通常指数增加。")
    print("2. 记录数增加 -> 运行时间近似线性增加，cuboid数基本稳定。")
    print("3. k值增大 -> 运行时间减少，输出cuboid数减少（剪枝更激进）。")